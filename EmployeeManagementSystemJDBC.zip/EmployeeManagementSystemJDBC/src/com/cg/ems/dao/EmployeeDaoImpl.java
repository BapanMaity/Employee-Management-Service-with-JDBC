package com.cg.ems.dao;

import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;



import java.util.Iterator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.*;

public class EmployeeDaoImpl implements EmployeeDao {
     
    Connection con=null; 
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs= null;
	
	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		
		try 
		{
			con=DButil.getCon();
			pst=con.prepareStatement(QueryMapper.INSERTQRY3);
			pst.setInt(1, ee.getEmpId());
			pst.setString(2, ee.getEmpName());
			pst.setFloat(3, ee.getEmpSal());
			int data=pst.executeUpdate();
			if(data==1)
			{
				return ee.getEmpId();				
			}
			else
			{return 0;}
		} 
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
			//e.printStackTrace();
		}
		finally{}
	}

	@Override
	public HashSet<Employee> fetchallEmp() {
		return null;
		
		
	}

	@Override
	public Employee getEmpId(int empId) {
		return null;
		
	}

	@Override
	public HashSet<Employee> searchEmpByName(String name) {
		return null;
		
	}

	@Override
	public int deleteEmp(int empId) 
	     {
			return empId;
	}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		return null;
	
	}
}	



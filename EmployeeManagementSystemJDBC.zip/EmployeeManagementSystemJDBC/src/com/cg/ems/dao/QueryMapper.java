package com.cg.ems.dao;

public interface QueryMapper {
	public static final 
	
	String SELECTQRY1="SELECT* From emp160630";
	//dynamic query,-runtime
	String SELECTQRY2="SELECT* From emp160630 WHERE emp_id=?";
	public static final	String INSERTQRY1=
			"INSERT INTO emp160630 VALUES(222,'SUNIL',34000,SYSDATE)";
	public static final	String INSERTQRY2=
			"INSERT INTO emp160630 (emp_id,'emp_name',emp_sal,SYSDATE)"
	+"VALUES(444,'Amit',60000)";
	
	//For runtime insertion we use this code//
	public static final	String INSERTQRY3=
			"INSERT INTO emp160630(emp_id,emp_name,emp_sal)VALUES(?,?,?)";
	public static final String UPDATEQRY="UPDATE emp160630 SET emp_name=?,"
			+ " emp_sal=? where emp_id=?";
	public static final String DELETEQRY="DELETE FROM emp160630  where emp_id=?";
	

}

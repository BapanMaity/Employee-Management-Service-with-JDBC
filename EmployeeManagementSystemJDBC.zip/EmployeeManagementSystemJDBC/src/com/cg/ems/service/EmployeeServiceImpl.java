package com.cg.ems.service;

import java.util.HashSet;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao empDao=null;
	public EmployeeServiceImpl(){
		empDao= new EmployeeDaoImpl();
	}
	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		return empDao.addEmployee(ee);
		
	}

	@Override
	public HashSet<Employee> fetchallEmp() {
		
		return empDao.fetchallEmp();
	}

	@Override
	public Employee getEmpId(int empId) {
		
		return empDao.getEmpId(empId);
	}

	@Override
	public HashSet<Employee> searchEmpByName(String name) {
			return empDao.searchEmpByName(name);
	}

	@Override
	public int deleteEmp(int empId) {
		
		return empDao.deleteEmp(empId);
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		
		return empDao.updateEmp(empId, newName, newSal);
	}

	@Override
	public boolean validateDigit(int num) throws EmployeeException {
		Integer input= new Integer(num);
		String inputStr=input.toString();
		String digitPattern="[0-9]+";
		if(Pattern.matches(digitPattern, inputStr))
	    {
			return true;
		}
		else{
			throw new EmployeeException("Invalid input"+ "only digits are allowed ex. 6431");
		}
		
	}

	@Override
	public boolean validateName(String name) throws EmployeeException {
		
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, name))
			return true;
		else
			throw new EmployeeException("Invalid input...name  starts with capital eg. Bapan");
	}

}

package com.cg.ems.ui;

import java.util.*;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;


public class TestEmployeeClient {
	static Scanner sc=null;
    static EmployeeService empSer=null;

    public static void main(String[] args) 
	{
      sc=new Scanner(System.in);
      empSer=new EmployeeServiceImpl();
      int choice=0;
      while (true){
    	  System.out.println("1.Add Employee");
    	  System.out.println("2.Fetch All Employee"); 
    	  System.out.println("3.Delete Employee");
    	  System.out.println("4.Search Employee by EmpId");
    	  System.out.println("5.Search Employee by name");
    	  System.out.println("6.Update Employee");
    	  System.out.println("7.Exit");
    	  
    	  choice=sc.nextInt();
    	  switch(choice){
    	  case 1: addEmp(); break;
    	  case 2: showEmpInfo(); break;
    	  case 3: delEmp();break;
    	  case 4: getempId(); break;
    	  case 5: getEmpbyName(); break;
    	  case 6: updateEmp(); break;
    	  default:System.exit(0);
    	  
    	  }
      }
	}
   
	private static void updateEmp() {
		System.out.println("Enter the Eployee ID , to be updated:");
		
		Scanner sc= new Scanner(System.in);
		int eid=sc.nextInt();
		System.out.println("Enter new name:");
		String newName=sc.next();
		System.out.println("Enter New salary");
		float newSal=sc.nextFloat();
		
		empSer.updateEmp(eid, newName, newSal);
		System.out.println("Employee ID- "+eid+" updated"+
		"\n Updated employee details are:");
		System.out.println("EmpID: "+eid+"Name: "+newName+"Salary: "+newSal);
		
	}

	private static void delEmp() {
		System.out.println("Enter Employee Id , to be deleted:");
		Scanner sc=new Scanner(System.in);
		int eid =sc.nextInt();
		empSer.deleteEmp(eid);
		System.out.println("Employee ID  "+eid+"  Deletion is completed");
	}

	private static void showEmpInfo()  {
    	HashSet<Employee> emp= empSer.fetchallEmp();
    	java.util.Iterator<Employee> it=emp.iterator();
    	System.out.println("------------------------");
    	System.out.println("EMPID\t\tEmpName\t\tEmpSalary");
    	while(it.hasNext())
    	{
    		Employee e=it.next();
    		System.out.println(e.getEmpId()+"\t\t"+e.getEmpName()+"\t\t"+e.getEmpSal());
    	}
    	
    }
	private static void getEmpbyName(){
		System.out.println("Enter employee name::");
		String name = sc.next();
        HashSet<Employee> has=empSer.searchEmpByName(name);
        System.out.println(has);
		
	}
	
	
	
	private static void getempId(){
		System.out.println("Enter the id :");
		int eeid = sc.nextInt();
		Employee e=empSer.getEmpId(eeid);
		System.out.println(e);
		
	}
	

	private static void addEmp(){
    	System.out.println("Enter Employee id:");
    	int empId=sc.nextInt();
    	try {
    		if (empSer.validateDigit(empId))
    		{
    		  System.out.println("Enter Emp name: ");
    		  String nm= sc.next();
    		  if(empSer.validateName(nm))
    		  {
    			  System.out.println("Enter Salary: ");
    			  float sal=sc.nextFloat();
    			  Employee e= new Employee(empId, nm, sal);
    			  int eid=empSer.addEmployee(e);
    			  System.out.println(eid+"  Added Successfully");
    			  
    		  }
    		}
    	}catch(EmployeeException e){
    		e.printStackTrace();
    	}
    	
    }

}
